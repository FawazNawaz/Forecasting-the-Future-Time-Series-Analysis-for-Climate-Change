Problem: Wind power forecasting

Learnables:
 - Univariate time series forecasting
 - Forecasting as a supervised learning problem 
 - Cross-validation
   - Nested splits
 - Evaluation